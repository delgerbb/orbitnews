<div class='four column carousel-item'>
    <a href='#'><img src='http://placehold.it/300x250' alt=''></a>

    <div class='post-container'>
        <h2 class='post-title'>Create a Flexible Folded Paper Effect Using CSS3 Features</h2>
        <div class='post-content'>
            <p>Venenatis volutpat orci, ut sodales augue tempor nec. Integer tempus ullamcorper felis eget dipiscing. Maecenas orci justo, mollis at tempus ac, gravida non</p>
        </div>
    </div>

    <div class='post-meta'>
        <span class='comments'><a href='#'>24</a></span>
        <span class='date'><a href='#'>13 Jan 2013</a></span>
    </div>
</div>