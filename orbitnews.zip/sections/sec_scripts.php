<script type="text/javascript" src="<?= JS_PATH; ?>jquery.min.js"></script>
<script type="text/javascript" src="<?= JS_PATH; ?>jquery.superfish.js"></script>
<script type="text/javascript" src="<?= JS_PATH; ?>jquery.flexslider.min.js"></script>
<script type="text/javascript" src="<?= JS_PATH; ?>jquery.fancybox.js"></script>
<script type="text/javascript" src="<?= JS_PATH; ?>jcarousel.js"></script>
<script type="text/javascript" src="<?= JS_PATH; ?>jquery.masonry.min.js"></script>
<script type="text/javascript" src="<?= JS_PATH; ?>script.js"></script>