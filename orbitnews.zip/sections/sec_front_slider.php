<!-- Slider -->
<div class="flexslider mb25">
    <ul class="slides no-bullet inline-list m0">
        <?php
            echo($printFace->printFrontSlidePosts());
        ?>
        <!--
        <li>
            <a href="#"><img alt="" src="http://placehold.it/620x350"></a>
            <div class="flex-caption">
                <div class="desc">
                    <h1><a href="#">Maecenas mattis, tortor ut posuere aliquam.</a></h1>
                    <p>This is Photoshop's version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor This is Photoshop's version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor</p>
                </div>
            </div>
        </li>
        <li>
            <a href="#"><img alt="" src="http://placehold.it/620x350"></a>
            <div class="flex-caption">
                <div class="desc">
                    <h1><a href="#">Maecenas mattis</a></h1>
                    <p>This is Photoshop's version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor</p>
                </div>
            </div>
        </li>
        <li>
            <a href="#"><img alt="" src="http://placehold.it/620x350"></a>
            <div class="flex-caption">
                <div class="desc">
                    <h1><a href="#">Maecenas mattis, tortor ut posuere aliquam, tortor ut posuere aliquam, tortor ut posuere aliquam</a></h1>
                    <p>This is Photoshop's version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor</p>
                </div>
            </div>
        </li>
        <li>
            <a href="#"><img alt="" src="http://placehold.it/620x350"></a>
            <div class="flex-caption">
                <div class="desc">
                    <h1><a href="#">Maecenas mattis, tortor ut posuere aliquam, tortor ut posuere aliquam, tortor ut posuere aliquam</a></h1>
                    <p>This is Photoshop's version  of Lorem Ipsum. Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis bibendum auctor</p>
                </div>
            </div>
        </li>
        -->
    </ul>
</div>
<!-- End Slider -->