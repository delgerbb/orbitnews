<link rel="shortcut icon" href="/assets/images/favicon.ico" type="image/x-icon">

<link href='http://fonts.googleapis.com/css?family=PT+Sans:400,700' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Oswald:400,700' rel='stylesheet' type='text/css'>

<link rel="stylesheet" href="<?= CSS_PATH; ?>foundation.css" type="text/css" media="screen">
<link rel="stylesheet" href="<?= CSS_PATH; ?>style.css" type="text/css" media="screen">
<link rel="stylesheet" href="<?= CSS_PATH; ?>responsive.css" type="text/css" media="screen">

<!--[if lt IE 9]>
        <script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->