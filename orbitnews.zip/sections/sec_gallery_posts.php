<!-- Gallery Posts -->
<div class="clearfix mb25 oh">
    <h4 class="cat-title">Gallery</h4>
    <!-- jCarousel -->
    <div class="carousel-container">
        <div class="carousel-navigation">
            <a class="carousel-prev"></a>
            <a class="carousel-next"></a>
        </div>
        <div class="carousel-item-holder gallery row" data-index="0">
            <div class="four column carousel-item">
                <a href="#"><img src="http://placehold.it/300x250" alt=""></a>
            </div>
            <div class="four column carousel-item">
                <a href="#"><img src="http://placehold.it/300x250" alt=""></a>
            </div>
            <div class="four column carousel-item">
                <a href="#"><img src="http://placehold.it/300x250" alt=""></a>
            </div>
            <div class="four column carousel-item">
                <a href="#"><img src="http://placehold.it/300x250" alt=""></a>
            </div>
            <div class="four column carousel-item">
                <a href="#"><img src="http://placehold.it/300x250" alt=""></a>
            </div>
        </div>
    </div>
    <!-- End jCarousel -->
</div>
<!-- End Gallery Posts -->