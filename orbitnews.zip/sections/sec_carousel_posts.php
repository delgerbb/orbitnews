<!-- Carousel Posts -->
<div class="clearfix mb10 oh">
    <h4 class="cat-title">Business</h4>
    <!-- jCarousel -->
    <div class="carousel-container">
        <div class="carousel-navigation">
            <a class="carousel-prev"></a>
            <a class="carousel-next"></a>
        </div>
        <div class="carousel-item-holder row" data-index="0">
            <?php
            echo($printFace->printCarouselEightPosts(8001));
            ?>
            <!--
            <div class="four column carousel-item">
                <a href="#"><img src="http://placehold.it/300x250" alt=""></a>

                <div class="post-container">
                    <h2 class="post-title">Create a Flexible Folded Paper Effect Using CSS3 Features</h2>
                    <div class="post-content">
                        <p>Venenatis volutpat orci, ut sodales augue tempor nec. Integer tempus ullamcorper felis eget dipiscing. Maecenas orci justo, mollis at tempus ac, gravida non</p>
                    </div>
                </div>

                <div class="post-meta">
                    <span class="comments"><a href="#">24</a></span>
                    <span class="date"><a href="#">13 Jan 2013</a></span>
                </div>
            </div>
            <div class="four column carousel-item">
                <a href="#"><img src="http://placehold.it/300x250" alt=""></a>

                <div class="post-container">
                    <h2 class="post-title">Create a Flexible Folded Paper Effect Using CSS3 Features</h2>
                    <div class="post-content">
                        <p>Venenatis volutpat orci, ut sodales augue tempor nec. Integer tempus ullamcorper felis eget dipiscing. Maecenas orci justo, mollis at tempus ac, gravida non</p>
                    </div>
                </div>

                <div class="post-meta">
                    <span class="comments"><a href="#">24</a></span>
                    <span class="date"><a href="#">13 Jan 2013</a></span>
                </div>
            </div>
            <div class="four column carousel-item">
                <a href="#"><img src="http://placehold.it/300x250" alt=""></a>

                <div class="post-container">
                    <h2 class="post-title">Create a Flexible Folded Paper Effect Using CSS3 Features</h2>
                    <div class="post-content">
                        <p>Venenatis volutpat orci, ut sodales augue tempor nec. Integer tempus ullamcorper felis eget dipiscing. Maecenas orci justo, mollis at tempus ac, gravida non</p>
                    </div>
                </div>

                <div class="post-meta">
                    <span class="comments"><a href="#">24</a></span>
                    <span class="date"><a href="#">13 Jan 2013</a></span>
                </div>
            </div>
            <div class="four column carousel-item">
                <a href="#"><img src="http://placehold.it/300x250" alt=""></a>

                <div class="post-container">
                    <h2 class="post-title">Create a Flexible Folded Paper Effect Using CSS3 Features</h2>
                    <div class="post-content">
                        <p>Venenatis volutpat orci, ut sodales augue tempor nec. Integer tempus ullamcorper felis eget dipiscing. Maecenas orci justo, mollis at tempus ac, gravida non</p>
                    </div>
                </div>

                <div class="post-meta">
                    <span class="comments"><a href="#">24</a></span>
                    <span class="date"><a href="#">13 Jan 2013</a></span>
                </div>
            </div>
            <div class="four column carousel-item">
                <a href="#"><img src="http://placehold.it/300x250" alt=""></a>

                <div class="post-container">
                    <h2 class="post-title">Create a Flexible Folded Paper Effect Using CSS3 Features</h2>
                    <div class="post-content">
                        <p>Venenatis volutpat orci, ut sodales augue tempor nec. Integer tempus ullamcorper felis eget dipiscing. Maecenas orci justo, mollis at tempus ac, gravida non</p>
                    </div>
                </div>

                <div class="post-meta">
                    <span class="comments"><a href="#">24</a></span>
                    <span class="date"><a href="#">13 Jan 2013</a></span>
                </div>
            </div>
            -->
        </div>
    </div>
    <!-- End jCarousel -->
</div>
<!-- End Carousel Posts -->