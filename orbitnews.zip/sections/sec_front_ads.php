<!-- Ads -->
<div class="ads-middle mb25">
    <a href="#"><img src="http://placehold.it/468x60" alt=""></a>
</div>
<!-- Ads -->